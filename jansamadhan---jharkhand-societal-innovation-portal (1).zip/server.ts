import express from "express";
import cookieParser from "cookie-parser";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import crypto from "crypto";
import nodemailer from "nodemailer";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: "15mb" }));
app.use(express.urlencoded({ extended: true, limit: "15mb" }));
app.use(cookieParser());

// Uploads directory
const uploadsDir = path.resolve(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}
const upload = multer({
  dest: uploadsDir,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

// Categories & Priority keyword rules
const categories: Record<string, string[]> = {
  Education: ["school", "teacher", "student", "college", "education", "learning"],
  Healthcare: ["hospital", "health", "doctor", "medicine", "ambulance", "clinic"],
  Environment: ["waste", "pollution", "forest", "environment", "garbage"],
  Energy: ["electricity", "power", "solar", "energy", "streetlight"],
  "Urban Development": ["road", "traffic", "bridge", "urban", "transport"],
  Accessibility: ["disabled", "wheelchair", "accessibility", "ramp", "blind"],
  "Public Administration": ["certificate", "pension", "ration", "government", "service"],
  "Rural Livelihoods": ["livelihood", "self help", "artisan", "village", "rural"],
};

function classify(text: string) {
  const value = text.toLowerCase();
  let best = "Public Administration";
  let score = 0;
  for (const [category, words] of Object.entries(categories)) {
    const current = words.filter((word) => value.includes(word)).length;
    if (current > score) {
      best = category;
      score = current;
    }
  }
  return best;
}

function priority(text: string) {
  const value = text.toLowerCase();
  if (["emergency", "death", "unsafe", "contaminated", "accident", "hospital"].some((w) => value.includes(w))) return "Critical";
  if (["urgent", "school", "health", "energy", "road"].some((w) => value.includes(w))) return "High";
  return "Medium";
}

const progressByStatus: Record<string, number> = {
  Submitted: 10,
  "Under Review": 22,
  Validated: 38,
  Assigned: 52,
  "In Progress": 68,
  Pilot: 84,
  Implemented: 100,
};

function workflowMessage(status: string) {
  const messages: Record<string, string> = {
    Submitted: "The challenge has been received and queued for screening.",
    "Under Review": "Government reviewers are checking the problem statement and evidence.",
    Validated: "The issue has been validated and is ready for institutional matching.",
    Assigned: "An eligible university team has been assigned to prepare a solution approach.",
    "In Progress": "The assigned team is actively researching and building the solution.",
    Pilot: "The solution is being tested with the affected community.",
    Implemented: "The solution has been verified and implemented for community use.",
  };
  return messages[status] || "The challenge workflow was updated.";
}

// In-Memory Data Store (seeded with demo datasets)
interface Challenge {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: string;
  status: string;
  district: string;
  village?: string;
  address?: string;
  latitude?: number;
  longitude?: number;
  submitter_name?: string;
  submitter_type?: string;
  contact?: string;
  evidence_key?: string;
  assigned_institution?: string;
  industry_partner?: string;
  impact_score?: number;
  created_at?: string;
}

interface Project {
  id: string;
  challenge_id: string;
  title: string;
  stage: string;
  progress: number;
  institution: string;
  industry?: string;
  faculty_lead?: string;
  next_milestone?: string;
  due_date?: string;
  created_at?: string;
}

interface Partner {
  id: string;
  name: string;
  type: string;
  expertise: string;
  district?: string;
  engagement: string;
}

interface Notice {
  id: string;
  title: string;
  message: string;
  audience: string;
  is_read?: number;
  created_at: string;
}

interface ProgressUpdate {
  id: string;
  challenge_id: string;
  stage: string;
  progress: number;
  message: string;
  actor: string;
  created_at: string;
}

interface Proposal {
  id: string;
  challenge_id: string;
  proposer_name: string;
  proposer_role: string;
  institution: string;
  title: string;
  description: string;
  status: string;
  created_at: string;
}

interface User {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: string;
  created_at: string;
}

interface Session {
  id: string;
  user_id: string;
  token: string;
  expires_at: number;
}

interface OtpRecord {
  challengeId: string;
  email: string;
  mode: "login" | "signup";
  payload: any;
  otp: string;
  attempts: number;
  expiresAt: number;
  resendAt: number;
  resendsLeft: number;
}

const createdTime = new Date().toISOString();

interface ChatMessage {
  id: string;
  channel: string;
  senderName: string;
  senderRole: string;
  text: string;
  challengeId?: string;
  challengePreview?: {
    id: string;
    title: string;
    status: string;
    district: string;
    progress: number;
    category: string;
  };
  isOfficial?: boolean;
  timestamp: string;
  likes?: number;
}

const initialChatMessages: ChatMessage[] = [
  {
    id: "MSG-101",
    channel: "helpdesk",
    senderName: "JanSamadhan Desk",
    senderRole: "Government Helpdesk",
    text: "Namaste! Welcome to JanSamadhan Citizen Helpdesk. Ask questions about reporting local issues, tracking challenge progress, or connecting with universities and departments across Jharkhand.",
    isOfficial: true,
    timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
    likes: 12,
  },
  {
    id: "MSG-102",
    channel: "helpdesk",
    senderName: "Pooja Soren",
    senderRole: "Citizen",
    text: "Our village panchayat in Khunti needs solar microgrid power support. How do we lodge this so BIT Mesra or CUJ can evaluate it?",
    timestamp: new Date(Date.now() - 3600000 * 3).toISOString(),
    likes: 4,
  },
  {
    id: "MSG-103",
    channel: "helpdesk",
    senderName: "JanSamadhan Desk",
    senderRole: "Government Helpdesk",
    text: "Pooja ji, you can click '+ Submit challenge' at the top bar. Choose 'Energy' domain and 'Khunti' district, upload location or photos. Once submitted, our screening desk validates it within 48 hours and lists it on the Solver Hub for university assignment.",
    isOfficial: true,
    timestamp: new Date(Date.now() - 3600000 * 2.5).toISOString(),
    likes: 8,
  },
  {
    id: "MSG-104",
    channel: "tracker",
    senderName: "Ramesh Mahto",
    senderRole: "Citizen",
    text: "Could someone share the latest development update on maternal health screening challenge JH-24018?",
    challengeId: "JH-24018",
    challengePreview: {
      id: "JH-24018",
      title: "Remote maternal health screening & diagnostic access",
      status: "In Progress",
      district: "Palamu",
      progress: 68,
      category: "Healthcare",
    },
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
    likes: 5,
  },
  {
    id: "MSG-105",
    channel: "tracker",
    senderName: "Dr. A. Sinha (AIIMS Deoghar)",
    senderRole: "University",
    text: "Greetings Ramesh ji. AIIMS Deoghar team in partnership with Apollo Telehealth completed the prototype sensor calibration. Field pilot testing is currently active in Hussainabad block with 68% milestone completion.",
    challengeId: "JH-24018",
    timestamp: new Date(Date.now() - 3600000 * 3.2).toISOString(),
    likes: 15,
  },
  {
    id: "MSG-106",
    channel: "innovators",
    senderName: "Prof. R. Toppo",
    senderRole: "University",
    text: "IIT (ISM) Dhanbad has deployed the solar microgrid pilot unit at Latehar (JH-23984). Village hamlets are maintaining 24x7 clean power and street lighting. We welcome feedback from other panchayats.",
    challengeId: "JH-23984",
    challengePreview: {
      id: "JH-23984",
      title: "Decentralised clean microgrid & solar street lighting",
      status: "Pilot",
      district: "Latehar",
      progress: 82,
      category: "Energy",
    },
    timestamp: new Date(Date.now() - 3600000 * 6).toISOString(),
    likes: 18,
  },
  {
    id: "MSG-107",
    channel: "innovators",
    senderName: "KissanPro Labs Team",
    senderRole: "Industry",
    text: "Telemetry sensors are online at Kanke cold-room. Chamber temperature is maintaining 6-8°C under solar power. Next cohort review scheduled for 26 Sep.",
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    likes: 9,
  },
  {
    id: "MSG-108",
    channel: "rural",
    senderName: "Sita Devi",
    senderRole: "Citizen",
    text: "Are there low-cost solar grain dryers available for women Self Help Groups in Santhal Pargana region?",
    timestamp: new Date(Date.now() - 3600000 * 7).toISOString(),
    likes: 6,
  },
  {
    id: "MSG-109",
    channel: "rural",
    senderName: "CUJ Rural Tech Cell",
    senderRole: "University",
    text: "Yes! Central University of Jharkhand has a pilot low-cost parabolic solar dryer blueprint under testing. We can conduct a demonstration workshop for your SHG cluster.",
    timestamp: new Date(Date.now() - 3600000 * 4.5).toISOString(),
    likes: 11,
  },
];

const store = {
  chatMessages: [...initialChatMessages] as ChatMessage[],
  challenges: [
    {
      id: "JH-24018",
      title: "Remote maternal health screening & diagnostic access",
      description: "Primary health centres in remote forest blocks lack rapid diagnostic tools for high-risk pregnancies.",
      category: "Healthcare",
      priority: "Critical",
      status: "In Progress",
      district: "Palamu",
      village: "Hussainabad",
      address: "Hussainabad block",
      latitude: 24.04,
      longitude: 84.08,
      submitter_name: "Community Health Group",
      submitter_type: "Community organisation",
      contact: "9000000001",
      assigned_institution: "AIIMS Deoghar & RIMS",
      industry_partner: "Apollo Telehealth",
      impact_score: 94,
      created_at: createdTime,
    },
    {
      id: "JH-23984",
      title: "Decentralised clean microgrid & solar street lighting",
      description: "Off-grid tribal hamlets experience frequent blackouts affecting village safety and study hours.",
      category: "Energy",
      priority: "High",
      status: "Pilot",
      district: "Latehar",
      village: "Mahuadanr",
      address: "Mahuadanr block",
      latitude: 23.40,
      longitude: 84.11,
      submitter_name: "Panchayat Energy Committee",
      submitter_type: "Community organisation",
      contact: "9000000002",
      assigned_institution: "IIT (ISM) Dhanbad",
      industry_partner: "Tata Power Solar",
      impact_score: 86,
      created_at: createdTime,
    },
    {
      id: "JH-23941",
      title: "Accessible learning tools for tribal schools",
      description: "Offline multilingual learning support is needed in low-connectivity blocks.",
      category: "Education",
      priority: "High",
      status: "Assigned",
      district: "West Singhbhum",
      village: "Chaibasa",
      address: "Chaibasa",
      latitude: 22.55,
      longitude: 85.80,
      submitter_name: "School Management Committee",
      submitter_type: "Citizen",
      contact: "9000000003",
      assigned_institution: "Central University of Jharkhand",
      impact_score: 82,
      created_at: createdTime,
    },
    {
      id: "JH-23876",
      title: "Overflowing waste points near public market",
      description: "Smart collection scheduling and citizen reporting required.",
      category: "Environment",
      priority: "Medium",
      status: "Validated",
      district: "Dhanbad",
      village: "Bank More",
      address: "Bank More",
      latitude: 23.80,
      longitude: 86.43,
      submitter_name: "Market Committee",
      submitter_type: "Community organisation",
      contact: "9000000004",
      impact_score: 68,
      created_at: createdTime,
    },
  ] as Challenge[],

  projects: [
    {
      id: "PRJ-1042",
      challenge_id: "JH-24018",
      title: "JanSwasthya portable diagnostic kit",
      stage: "Prototype",
      progress: 68,
      institution: "AIIMS Deoghar",
      industry: "Apollo Telehealth",
      faculty_lead: "Dr. A. Sinha",
      next_milestone: "PHC field calibration",
      due_date: "18 Oct",
      created_at: createdTime,
    },
    {
      id: "PRJ-1018",
      challenge_id: "JH-23984",
      title: "GramUrja smart solar microgrid",
      stage: "Pilot",
      progress: 82,
      institution: "IIT (ISM) Dhanbad",
      industry: "Tata Power Solar",
      faculty_lead: "Prof. R. Toppo",
      next_milestone: "Village cluster review",
      due_date: "26 Sep",
      created_at: createdTime,
    },
    {
      id: "PRJ-997",
      challenge_id: "JH-23941",
      title: "Akhra offline learning kit",
      stage: "Research",
      progress: 41,
      institution: "CUJ",
      industry: "EdVantage",
      faculty_lead: "Dr. M. Ekka",
      next_milestone: "Prototype content pack",
      due_date: "09 Nov",
      created_at: createdTime,
    },
  ] as Project[],

  partners: [
    {
      id: "P1",
      name: "BIT Mesra",
      type: "University",
      expertise: "Engineering · AI · IoT",
      district: "Ranchi",
      engagement: "4 active projects",
    },
    {
      id: "P2",
      name: "IIT (ISM) Dhanbad",
      type: "University",
      expertise: "Clean Energy · Rural Innovation",
      district: "Dhanbad",
      engagement: "3 active projects",
    },
    {
      id: "P3",
      name: "Tata Steel Foundation",
      type: "CSR Partner",
      expertise: "Funding · Field implementation",
      district: "East Singhbhum",
      engagement: "₹42L committed",
    },
    {
      id: "P4",
      name: "KissanPro Labs",
      type: "Startup",
      expertise: "AgriTech · IoT · Cold chain",
      district: "Ranchi",
      engagement: "2 pilots",
    },
  ] as Partner[],

  notifications: [
    {
      id: "NOTIF-1",
      title: "Healthcare Challenge Field Evaluation",
      message: "AIIMS Deoghar doctors deployed maternal health screening kits in Palamu.",
      audience: "Government",
      created_at: createdTime,
    },
    {
      id: "NOTIF-2",
      title: "Clean Energy Microgrid Review",
      message: "IIT (ISM) Dhanbad scheduled village council review for Latehar solar pilot.",
      audience: "Citizen",
      created_at: createdTime,
    },
    {
      id: "NOTIF-3",
      title: "New Societal Challenge Submitted",
      message: "West Singhbhum district received educational tools proposal.",
      audience: "University",
      created_at: createdTime,
    },
  ] as Notice[],

  updates: [
    {
      id: "UPD-1",
      challenge_id: "JH-24018",
      stage: "In Progress",
      progress: 68,
      message: "Sensor field calibration underway with Tata Steel Foundation support.",
      actor: "BIT Mesra lead researcher",
      created_at: createdTime,
    },
    {
      id: "UPD-2",
      challenge_id: "JH-23984",
      stage: "Pilot",
      progress: 82,
      message: "Micro cold-room installed at Kanke agricultural hub.",
      actor: "BAU Ranchi AgriTech team",
      created_at: createdTime,
    },
  ] as ProgressUpdate[],

  proposals: [
    {
      id: "SOL-101",
      challenge_id: "JH-24018",
      proposer_name: "Dr. A. Sinha",
      proposer_role: "University",
      institution: "BIT Mesra",
      title: "Electrochemical Fluoride Filter with IoT Telemetry",
      description: "Low-cost adsorption filtration unit with automated alert when filter replacement is required.",
      status: "Under Review",
      created_at: createdTime,
    },
  ] as Proposal[],

  votes: new Map<string, Set<string>>(), // challengeId -> Set of phone/email
  users: [
    {
      id: "USR-DEMO",
      name: "Jharkhand Innovation Admin",
      phone: "9800000000",
      email: "admin@jansamadhan.jharkhand.gov.in",
      role: "Government",
      created_at: createdTime,
    },
  ] as User[],

  sessions: new Map<string, Session>(), // token -> Session
  otps: new Map<string, OtpRecord>(), // challengeId -> OtpRecord
  comments: [] as any[],
  serviceBookings: [] as any[],
};

// Seed initial votes
store.votes.set("JH-24018", new Set(["9000000001", "9000000002", "9000000003"]));
store.votes.set("JH-23984", new Set(["9000000004", "9000000005"]));

function maskEmail(email: string) {
  const [local, domain] = email.split("@");
  if (!domain) return email;
  if (local.length <= 2) return `${local[0]}***@${domain}`;
  return `${local[0]}***${local[local.length - 1]}@${domain}`;
}

function getSessionUser(req: express.Request): User | null {
  const token = req.cookies.js_session || (req.headers.authorization?.replace(/^Bearer\s+/i, "") ?? "");
  if (!token) return null;
  const session = store.sessions.get(token);
  if (!session) return null;
  if (session.expires_at <= Date.now()) {
    store.sessions.delete(token);
    return null;
  }
  return store.users.find((u) => u.id === session.user_id) || null;
}

// -------------------------------------------------------------
// API Routes
// -------------------------------------------------------------

// Portal GET
app.get("/api/portal", async (req, res) => {
  const action = req.query.action as string;

  // Session check
  if (action === "session") {
    const user = getSessionUser(req);
    if (!user) {
      return res.status(401).json({ authenticated: false });
    }
    return res.json({ authenticated: true, user });
  }

  // Village Search via Nominatim OpenStreetMap
  if (action === "villageSearch") {
    const q = String(req.query.q || "").trim();
    if (q.length < 2) return res.json({ villages: [] });
    try {
      const searchUrl = new URL("https://nominatim.openstreetmap.org/search");
      searchUrl.searchParams.set("q", `${q}, Jharkhand, India`);
      searchUrl.searchParams.set("format", "jsonv2");
      searchUrl.searchParams.set("addressdetails", "1");
      searchUrl.searchParams.set("limit", "8");
      searchUrl.searchParams.set("dedupe", "1");

      const response = await fetch(searchUrl.toString(), {
        headers: { "User-Agent": "JanSamadhan/1.0 societal-innovation-portal" },
      });
      if (!response.ok) {
        return res.status(502).json({ error: "Village search is temporarily unavailable." });
      }
      const results = (await response.json()) as Array<Record<string, any>>;
      const villages = results
        .map((item) => {
          const address = (item.address || {}) as Record<string, string>;
          return {
            name:
              address.village ||
              address.hamlet ||
              address.town ||
              address.city ||
              String(item.display_name || "").split(",")[0],
            displayName: item.display_name,
            latitude: Number(item.lat),
            longitude: Number(item.lon),
            district: address.county || address.state_district || "",
            state: address.state || "Jharkhand",
            type: item.type || "place",
            source: "OpenStreetMap / Nominatim",
          };
        })
        .filter((v) => Number.isFinite(v.latitude) && Number.isFinite(v.longitude));
      return res.json({ villages });
    } catch (err) {
      return res.status(502).json({ error: "Village search failed." });
    }
  }

  // Default: Return complete portal data
  const voteResults = Array.from(store.votes.entries()).map(([challenge_id, voters]) => ({
    challenge_id,
    votes: voters.size,
  }));

  return res.json({
    challenges: store.challenges,
    projects: store.projects,
    partners: store.partners,
    notifications: store.notifications,
    updates: store.updates,
    votes: voteResults,
    proposals: store.proposals,
  });
});

// Portal POST
app.post("/api/portal", async (req, res) => {
  try {
    const body = req.body || {};
    const action = String(body.action || "challenge");
    const now = new Date().toISOString();

    // 1. requestOtp
    if (action === "requestOtp") {
      const mode = body.mode === "signup" ? "signup" : "login";
      const email = String(body.email || "").trim().toLowerCase();
      if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
        return res.status(400).json({ error: "Enter a valid email address." });
      }

      let payload: any = {};
      if (mode === "signup") {
        const name = String(body.name || "").trim();
        const phone = String(body.phone || "").replace(/\D/g, "");
        const role = String(body.role || "Citizen").trim();
        if (name.length < 2) return res.status(400).json({ error: "Enter your full name." });
        if (phone.length !== 10) return res.status(400).json({ error: "Enter a valid 10-digit mobile number." });
        const existing = store.users.find((u) => u.email.toLowerCase() === email || u.phone === phone);
        if (existing) {
          return res.status(409).json({ error: "An account with this email or mobile already exists. Please log in." });
        }
        payload = { name, phone, role };
      } else {
        const user = store.users.find((u) => u.email.toLowerCase() === email);
        if (!user) {
          return res.status(404).json({ error: "No account found for this email. Please create an account first." });
        }
        payload = { role: body.role || user.role };
      }

      const challengeId = crypto.randomUUID();
      // Generate 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const masked = maskEmail(email);

      store.otps.set(challengeId, {
        challengeId,
        email,
        mode,
        payload,
        otp,
        attempts: 0,
        expiresAt: Date.now() + 300000, // 5 mins
        resendAt: Date.now() + 60000, // 1 min cooldown
        resendsLeft: 3,
      });

      // Attempt to send email if SMTP credentials are provided
      let emailed = false;
      if (process.env.SMTP_USER && process.env.SMTP_PASSWORD) {
        try {
          const transporter = nodemailer.createTransport({
            host: process.env.SMTP_HOST || "smtp.gmail.com",
            port: Number(process.env.SMTP_PORT) || 587,
            secure: process.env.SMTP_SECURITY === "tls",
            auth: {
              user: process.env.SMTP_USER,
              pass: process.env.SMTP_PASSWORD.replace(/\s+/g, ""),
            },
          });
          await transporter.sendMail({
            from: `"${process.env.OTP_FROM_NAME || "JanSamadhan"}" <${process.env.OTP_FROM_EMAIL || process.env.SMTP_USER}>`,
            to: email,
            subject: `Your JanSamadhan OTP: ${otp}`,
            text: `Your one-time login OTP is ${otp}. It will expire in 5 minutes.`,
            html: `<div style="font-family:sans-serif;padding:20px;border:1px solid #176b5b;border-radius:10px;"><h2>JanSamadhan Verification</h2><p>Your one-time verification code is:</p><p style="font-size:32px;font-weight:bold;letter-spacing:4px;color:#176b5b;">${otp}</p><p>This code expires in 5 minutes.</p></div>`,
          });
          emailed = true;
        } catch (e) {
          console.warn("[JanSamadhan] SMTP sending failed, falling back to instant code:", e);
        }
      }

      console.log(`[JanSamadhan] Generated OTP for ${email}: ${otp}`);

      return res.json({
        ok: true,
        message: emailed
          ? `A 6-digit OTP was sent to ${masked}.`
          : `OTP sent to ${masked} (Sandbox OTP: ${otp})`,
        challengeId,
        maskedEmail: masked,
        expiresIn: 300,
        resendIn: 60,
        resendsLeft: 3,
      });
    }

    // 2. resendOtp
    if (action === "resendOtp") {
      const challengeId = String(body.challengeId || "");
      const email = String(body.email || "").trim().toLowerCase();
      const record = store.otps.get(challengeId);
      if (!record || record.email !== email) {
        return res.status(400).json({ error: "Invalid OTP session. Please start again." });
      }
      if (record.resendAt > Date.now()) {
        const waitSec = Math.ceil((record.resendAt - Date.now()) / 1000);
        return res.status(429).json({ error: `Please wait ${waitSec}s before requesting a new OTP.`, retryAfter: waitSec });
      }
      if (record.resendsLeft <= 0) {
        return res.status(429).json({ error: "Maximum resend limit reached. Please start over." });
      }

      const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
      record.otp = newOtp;
      record.attempts = 0;
      record.expiresAt = Date.now() + 300000;
      record.resendAt = Date.now() + 60000;
      record.resendsLeft -= 1;

      console.log(`[JanSamadhan] Resent OTP for ${email}: ${newOtp}`);

      return res.json({
        ok: true,
        message: `A new OTP was sent to ${record.email}. (Sandbox OTP: ${newOtp})`,
        challengeId,
        maskedEmail: maskEmail(email),
        expiresIn: 300,
        resendIn: 60,
        resendsLeft: record.resendsLeft,
      });
    }

    // 3. verifyOtp
    if (action === "verifyOtp") {
      const challengeId = String(body.challengeId || "");
      const email = String(body.email || "").trim().toLowerCase();
      const enteredOtp = String(body.otp || "").replace(/\D/g, "");
      const record = store.otps.get(challengeId);

      if (!record || record.email !== email) {
        return res.status(400).json({ error: "This OTP session has expired or is invalid. Please start again." });
      }
      if (record.expiresAt < Date.now()) {
        return res.status(400).json({ error: "This OTP has expired. Please request a new one." });
      }
      if (record.otp !== enteredOtp) {
        record.attempts += 1;
        if (record.attempts >= 5) {
          store.otps.delete(challengeId);
          return res.status(429).json({ error: "Too many incorrect attempts. Please request a new OTP." });
        }
        return res.status(400).json({ error: "Invalid 6-digit OTP. Please double check." });
      }

      // Consumed
      store.otps.delete(challengeId);

      let user: User | null = null;
      if (record.mode === "signup") {
        user = {
          id: "USR-" + crypto.randomUUID().slice(0, 8).toUpperCase(),
          name: record.payload.name,
          phone: record.payload.phone,
          email,
          role: record.payload.role || "Citizen",
          created_at: now,
        };
        store.users.push(user);
      } else {
        user = store.users.find((u) => u.email.toLowerCase() === email) || null;
        if (!user) {
          return res.status(404).json({ error: "Account not found." });
        }
        if (record.payload.role) {
          user.role = record.payload.role;
        }
      }

      const token = crypto.randomUUID() + crypto.randomUUID();
      store.sessions.set(token, {
        id: crypto.randomUUID(),
        user_id: user.id,
        token,
        expires_at: Date.now() + 7 * 86400000,
      });

      res.cookie("js_session", token, {
        path: "/",
        httpOnly: true,
        sameSite: "lax",
        maxAge: 7 * 86400 * 1000,
      });

      return res.json({ ok: true, user });
    }

    // 4. logout
    if (action === "logout") {
      const token = req.cookies.js_session;
      if (token) store.sessions.delete(token);
      res.clearCookie("js_session", { path: "/" });
      return res.json({ ok: true });
    }

    // 5. challenge submission
    if (action === "challenge") {
      const title = String(body.title || "").trim();
      const description = String(body.description || "").trim();
      const district = String(body.district || "").trim();
      const submitterName = String(body.submitterName || "").trim();
      const submitterType = String(body.submitterType || "Citizen").trim();
      const contact = String(body.contact || "").trim();

      if (title.length < 8 || description.length < 30 || !district || !submitterName || !contact) {
        return res.status(400).json({ error: "Please complete all required challenge details." });
      }

      const id = "JH-" + crypto.randomUUID().slice(0, 8).toUpperCase();
      const detectedCategory = body.category ? String(body.category) : classify(title + " " + description);
      const detectedPriority = priority(title + " " + description);
      const impactScore = detectedPriority === "Critical" ? 92 : detectedPriority === "High" ? 78 : 62;

      const newChallenge: Challenge = {
        id,
        title,
        description,
        category: detectedCategory,
        priority: detectedPriority,
        status: "Submitted",
        district,
        village: body.village || undefined,
        address: body.address || undefined,
        latitude: body.latitude ? Number(body.latitude) : undefined,
        longitude: body.longitude ? Number(body.longitude) : undefined,
        submitter_name: submitterName,
        submitter_type: submitterType,
        contact,
        evidence_key: body.evidenceKey || undefined,
        impact_score: impactScore,
        created_at: now,
      };

      store.challenges.unshift(newChallenge);

      store.notifications.unshift({
        id: "NOTIF-" + crypto.randomUUID().slice(0, 8),
        title: "New challenge submitted",
        message: `${title} was submitted from ${district}.`,
        audience: "Government",
        created_at: now,
      });

      store.updates.unshift({
        id: "UPD-" + crypto.randomUUID().slice(0, 8),
        challenge_id: id,
        stage: "Submitted",
        progress: progressByStatus.Submitted,
        message: "Challenge received and queued for automated screening.",
        actor: "JanSamadhan system",
        created_at: now,
      });

      return res.status(201).json({ ok: true, id, category: detectedCategory, priority: detectedPriority });
    }

    // 6. updateChallenge
    if (action === "updateChallenge") {
      const id = String(body.id || "");
      const status = String(body.status || "");
      const challenge = store.challenges.find((c) => c.id === id);
      if (!challenge) return res.status(404).json({ error: "Challenge not found." });

      challenge.status = status;
      if (body.assignedInstitution) challenge.assigned_institution = String(body.assignedInstitution);
      if (body.industryPartner) challenge.industry_partner = String(body.industryPartner);

      const progress = progressByStatus[status] || 50;
      store.updates.unshift({
        id: "UPD-" + crypto.randomUUID().slice(0, 8),
        challenge_id: id,
        stage: status,
        progress,
        message: workflowMessage(status),
        actor: String(body.actor || "Government workflow"),
        created_at: now,
      });

      return res.json({ ok: true, progress });
    }

    // 7. challengeVote
    if (action === "challengeVote") {
      const challengeId = String(body.challengeId || "").trim();
      const user = getSessionUser(req);
      if (!user) {
        return res.status(401).json({ error: "Login with email OTP before voting." });
      }
      const challenge = store.challenges.find((c) => c.id === challengeId);
      if (!challenge) return res.status(404).json({ error: "Challenge not found." });

      let voterSet = store.votes.get(challengeId);
      if (!voterSet) {
        voterSet = new Set<string>();
        store.votes.set(challengeId, voterSet);
      }
      if (voterSet.has(user.id) || voterSet.has(user.phone) || voterSet.has(user.email)) {
        return res.status(409).json({ error: "You have already supported this challenge." });
      }

      voterSet.add(user.id);
      return res.status(201).json({ ok: true, votes: voterSet.size });
    }

    // 8. challengeComment
    if (action === "challengeComment") {
      const challengeId = String(body.challengeId || "").trim();
      const authorName = String(body.authorName || "").trim();
      const authorRole = String(body.authorRole || "Citizen").trim();
      const message = String(body.message || "").trim();
      if (!challengeId || authorName.length < 2 || message.length < 5) {
        return res.status(400).json({ error: "Please provide your name and a useful comment." });
      }
      store.comments.push({ id: crypto.randomUUID(), challengeId, authorName, authorRole, message, created_at: now });
      return res.status(201).json({ ok: true });
    }

    // 9. solutionProposal
    if (action === "solutionProposal") {
      const challengeId = String(body.challengeId || "").trim();
      const proposerName = String(body.proposerName || "").trim();
      const proposerRole = String(body.proposerRole || "University").trim();
      const institution = String(body.institution || "").trim();
      const title = String(body.title || "").trim();
      const description = String(body.description || "").trim();

      if (!challengeId || proposerName.length < 2 || institution.length < 2 || title.length < 5 || description.length < 20) {
        return res.status(400).json({ error: "Complete the solution proposal details." });
      }

      const challenge = store.challenges.find((c) => c.id === challengeId);
      if (!challenge) return res.status(404).json({ error: "Challenge not found." });

      const id = "SOL-" + crypto.randomUUID().slice(0, 8).toUpperCase();
      store.proposals.unshift({
        id,
        challenge_id: challengeId,
        proposer_name: proposerName,
        proposer_role: proposerRole,
        institution,
        title,
        description,
        status: "Submitted",
        created_at: now,
      });

      store.notifications.unshift({
        id: "NOTIF-" + crypto.randomUUID().slice(0, 8),
        title: "New solution proposal",
        message: `${institution} submitted a solution for ${challenge.title}.`,
        audience: "Government",
        created_at: now,
      });

      return res.status(201).json({ ok: true, id, status: "Submitted" });
    }

    // 10. publicReview
    if (action === "publicReview") {
      const projectId = String(body.projectId || "").trim();
      const projectTitle = String(body.projectTitle || "").trim();
      const name = String(body.name || "").trim();
      const rating = Math.max(1, Math.min(5, Number(body.rating || 0)));
      const review = String(body.review || "").trim();
      if (!projectId || !projectTitle || name.length < 2 || review.length < 10) {
        return res.status(400).json({ error: "Please provide a complete review." });
      }
      store.notifications.unshift({
        id: "NOTIF-" + crypto.randomUUID().slice(0, 8),
        title: `Public review · ${projectTitle}`,
        message: `${rating}/5 from ${name}: ${review}`,
        audience: `Government:${projectId}`,
        created_at: now,
      });
      return res.status(201).json({ ok: true });
    }

    // 11. projectGovernmentUpdate
    if (action === "projectGovernmentUpdate") {
      const projectId = String(body.projectId || "").trim();
      const challengeId = String(body.challengeId || "").trim();
      const projectTitle = String(body.projectTitle || "").trim();
      const message = String(body.message || "").trim();
      if (!projectId || !challengeId || !projectTitle || message.length < 12) {
        return res.status(400).json({ error: "A clear project update is required." });
      }
      store.updates.unshift({
        id: "UPD-" + crypto.randomUUID().slice(0, 8),
        challenge_id: challengeId,
        stage: "Government update",
        progress: 0,
        message,
        actor: `Project ${projectId}`,
        created_at: now,
      });
      store.notifications.unshift({
        id: "NOTIF-" + crypto.randomUUID().slice(0, 8),
        title: `Project update: ${projectTitle}`,
        message,
        audience: "Government",
        created_at: now,
      });
      return res.status(201).json({ ok: true });
    }

    // 12. project creation
    if (action === "project") {
      const title = String(body.title || "").trim();
      const challengeId = String(body.challengeId || "").trim();
      const institution = String(body.institution || "").trim();
      if (!title || !challengeId || !institution) {
        return res.status(400).json({ error: "Project title, challenge and institution are required." });
      }
      const id = "PRJ-" + crypto.randomUUID().slice(0, 8).toUpperCase();
      store.projects.unshift({
        id,
        challenge_id: challengeId,
        title,
        stage: body.stage || "Proposal",
        progress: Number(body.progress || 10),
        institution,
        industry: body.industry || undefined,
        faculty_lead: body.facultyLead || undefined,
        next_milestone: body.nextMilestone || undefined,
        due_date: body.dueDate || undefined,
        created_at: now,
      });
      return res.status(201).json({ ok: true, id });
    }

    // 13. partnerMessage
    if (action === "partnerMessage") {
      const partnerId = String(body.partnerId || "").trim();
      const partnerName = String(body.partnerName || "").trim();
      const sender = String(body.sender || "").trim();
      const contact = String(body.contact || "").trim();
      const message = String(body.message || "").trim();
      if (!partnerId || !partnerName || sender.length < 2 || contact.length < 5 || message.length < 10) {
        return res.status(400).json({ error: "Please complete your name, contact and message." });
      }
      store.notifications.unshift({
        id: "NOTIF-" + crypto.randomUUID().slice(0, 8),
        title: `Partner message for ${partnerName}`,
        message: `${sender} (${contact}): ${message}`,
        audience: `Partner:${partnerId}`,
        created_at: now,
      });
      return res.status(201).json({ ok: true, message: "Partner message routed successfully." });
    }

    // 14. serviceBooking
    if (action === "serviceBooking") {
      const serviceType = String(body.serviceType || "").trim();
      const facilityId = String(body.facilityId || "").trim();
      const facilityName = String(body.facilityName || "").trim();
      const citizenName = String(body.citizenName || "").trim();
      const phone = String(body.phone || "").replace(/\D/g, "");
      const district = String(body.district || "").trim();
      const bookingDate = String(body.bookingDate || "").trim();
      const timeSlot = String(body.timeSlot || "").trim();

      const id = "BKG-" + crypto.randomUUID().slice(0, 8).toUpperCase();
      const isAmbulance = serviceType === "Ambulance";
      store.serviceBookings.push({
        id,
        serviceType,
        facilityId,
        facilityName,
        citizenName,
        phone,
        district,
        bookingDate,
        timeSlot,
        quantity: body.quantity || null,
        notes: body.notes || null,
        latitude: body.latitude || null,
        longitude: body.longitude || null,
        status: isAmbulance ? "Dispatch requested" : "Requested",
        created_at: now,
      });

      store.notifications.unshift({
        id: "NOTIF-" + crypto.randomUUID().slice(0, 8),
        title: isAmbulance ? "New ambulance dispatch request" : `${serviceType} booking received`,
        message: isAmbulance
          ? `${id}: dispatch requested for ${citizenName} in ${district}. Open Ambulance Control to assign vehicle.`
          : `${id} was requested for ${facilityName} in ${district}.`,
        audience: isAmbulance ? "Ambulance control room" : "Government",
        created_at: now,
      });

      return res.status(201).json({
        ok: true,
        id,
        status: isAmbulance ? "Dispatch requested" : "Requested",
        message: isAmbulance ? "Ambulance control room was notified." : "Booking request submitted successfully.",
      });
    }

    return res.status(400).json({ error: "Unsupported action." });
  } catch (err: any) {
    console.error("Portal POST error:", err);
    return res.status(500).json({ error: "Could not process request." });
  }
});

// Directions POST
app.post("/api/directions", async (req, res) => {
  try {
    const { origin, destination } = req.body || {};
    if (!origin || !destination || typeof origin.lat !== "number" || typeof destination.lat !== "number") {
      return res.status(400).json({ error: "Send origin and destination as { lat, lng }." });
    }

    const mapplsToken = process.env.MAPPLS_ACCESS_TOKEN;
    if (mapplsToken) {
      const url = `https://route.mappls.com/route/direction/route_eta/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?geometries=geojson&overview=full&access_token=${mapplsToken}`;
      const r = await fetch(url);
      if (r.ok) {
        const d: any = await r.json();
        if (d.routes?.length) {
          const route = d.routes[0];
          return res.json({
            distanceMeters: Math.round(Number(route.distance || 0)),
            durationSeconds: Math.round(Number(route.duration || 0)),
            path: route.geometry.coordinates.map(([lng, lat]: [number, number]) => ({ lat, lng })),
          });
        }
      }
    }

    // Resilient fallback (OSRM project router or straight line interpolation)
    try {
      const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${origin.lng},${origin.lat};${destination.lng},${destination.lat}?overview=full&geometries=geojson`;
      const osrmResp = await fetch(osrmUrl, { headers: { "User-Agent": "JanSamadhan/1.0" } });
      if (osrmResp.ok) {
        const osrmData: any = await osrmResp.json();
        if (osrmData.routes?.length) {
          const route = osrmData.routes[0];
          return res.json({
            distanceMeters: Math.round(route.distance),
            durationSeconds: Math.round(route.duration),
            path: route.geometry.coordinates.map(([lng, lat]: [number, number]) => ({ lat, lng })),
          });
        }
      }
    } catch {
      // ignore osrm failure and interpolate
    }

    // Direct interpolation fallback
    const steps = 10;
    const path = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      path.push({
        lat: origin.lat + (destination.lat - origin.lat) * t,
        lng: origin.lng + (destination.lng - origin.lng) * t,
      });
    }
    const dLat = (destination.lat - origin.lat) * 111000;
    const dLng = (destination.lng - origin.lng) * 111000 * Math.cos((origin.lat * Math.PI) / 180);
    const distanceMeters = Math.round(Math.sqrt(dLat * dLat + dLng * dLng));
    const durationSeconds = Math.round((distanceMeters / 40000) * 3600); // 40 km/h

    return res.json({ distanceMeters, durationSeconds, path });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || "Directions request failed." });
  }
});

// -------------------------------------------------------------
// Chatbox API Routes
// -------------------------------------------------------------

// GET /api/chat
app.get("/api/chat", (req, res) => {
  const channel = String(req.query.channel || "all");
  const q = String(req.query.q || "").trim().toLowerCase();
  const challengeId = String(req.query.challengeId || "").trim();

  let messages = [...store.chatMessages];

  if (channel !== "all") {
    messages = messages.filter((m) => m.channel === channel);
  }

  if (challengeId) {
    messages = messages.filter((m) => m.challengeId?.toUpperCase() === challengeId.toUpperCase());
  }

  if (q) {
    messages = messages.filter(
      (m) =>
        m.text.toLowerCase().includes(q) ||
        m.senderName.toLowerCase().includes(q) ||
        m.senderRole.toLowerCase().includes(q) ||
        m.challengeId?.toLowerCase().includes(q)
    );
  }

  // Return sorted chronological
  messages.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  return res.json({
    messages,
    channels: [
      { id: "all", name: "All Channels", icon: "message-square" },
      { id: "helpdesk", name: "Citizen Helpdesk (सहायता)", icon: "landmark" },
      { id: "tracker", name: "Challenge Tracker (ट्रैकर)", icon: "target" },
      { id: "innovators", name: "Solvers & Universities (अनुसंधान)", icon: "graduation-cap" },
      { id: "rural", name: "Rural Innovation & Agri (कृषि)", icon: "sprout" },
    ],
  });
});

// POST /api/chat
app.post("/api/chat", (req, res) => {
  const { channel = "helpdesk", senderName, senderRole = "Citizen", text, challengeId } = req.body || {};
  const cleanText = String(text || "").trim();
  const cleanSender = String(senderName || "").trim() || "Concerned Citizen";
  const cleanRole = String(senderRole || "Citizen").trim();
  const validChannel = ["helpdesk", "tracker", "innovators", "rural"].includes(channel) ? channel : "helpdesk";

  if (!cleanText || cleanText.length < 2) {
    return res.status(400).json({ error: "Message cannot be empty." });
  }

  // Look for any Challenge ID mentioned in text or param
  let matchedChallengeId = challengeId ? String(challengeId).trim().toUpperCase() : undefined;
  if (!matchedChallengeId) {
    const idMatch = cleanText.match(/JH-\d{4,6}/i);
    if (idMatch) {
      matchedChallengeId = idMatch[0].toUpperCase();
    }
  }

  let challengePreview: any = undefined;
  if (matchedChallengeId) {
    const found = store.challenges.find((c) => c.id.toUpperCase() === matchedChallengeId);
    if (found) {
      const progress = progressByStatus[found.status] || 25;
      challengePreview = {
        id: found.id,
        title: found.title,
        status: found.status,
        district: found.district,
        progress,
        category: found.category,
      };
    }
  }

  const userMsg: ChatMessage = {
    id: "MSG-" + crypto.randomUUID().slice(0, 8),
    channel: validChannel,
    senderName: cleanSender,
    senderRole: cleanRole,
    text: cleanText,
    challengeId: matchedChallengeId,
    challengePreview,
    timestamp: new Date().toISOString(),
    likes: 0,
  };

  store.chatMessages.push(userMsg);

  // Generate automated official helpdesk reply when relevant
  let autoReply: ChatMessage | null = null;
  const lower = cleanText.toLowerCase();

  if (matchedChallengeId && challengePreview) {
    const found = store.challenges.find((c) => c.id === challengePreview.id);
    autoReply = {
      id: "MSG-" + crypto.randomUUID().slice(0, 8),
      channel: validChannel,
      senderName: "JanSamadhan Automated Desk",
      senderRole: "Government Helpdesk",
      isOfficial: true,
      text: `Status for ${challengePreview.id} (${challengePreview.title}): Currently in "${challengePreview.status}" stage (${challengePreview.progress}% progress). Assigned Institution: ${found?.assigned_institution || "In allocation process"}. Verified by district nodal office.`,
      challengeId: challengePreview.id,
      challengePreview,
      timestamp: new Date(Date.now() + 500).toISOString(),
      likes: 1,
    };
    store.chatMessages.push(autoReply);
  } else if (lower.includes("helpline") || lower.includes("emergency") || lower.includes("contact") || lower.includes("number")) {
    autoReply = {
      id: "MSG-" + crypto.randomUUID().slice(0, 8),
      channel: validChannel,
      senderName: "JanSamadhan Desk",
      senderRole: "Government Helpdesk",
      isOfficial: true,
      text: "Jharkhand State Emergency & Innovation Helplines:\n• CM JanSamadhan Helpline: 181\n• Emergency Police & Fire: 112\n• Ambulance Service: 108\n• Kisan Call Centre: 1800-180-1551\n• Drinking Water & Sanitation (DWSD): 1800-345-6512",
      timestamp: new Date(Date.now() + 500).toISOString(),
      likes: 2,
    };
    store.chatMessages.push(autoReply);
  } else if (lower.includes("how to submit") || lower.includes("lodging") || lower.includes("register challenge") || lower.includes("submit problem")) {
    autoReply = {
      id: "MSG-" + crypto.randomUUID().slice(0, 8),
      channel: validChannel,
      senderName: "JanSamadhan Desk",
      senderRole: "Government Helpdesk",
      isOfficial: true,
      text: "To submit a new challenge: Click the orange '+ Submit challenge' button in the top bar. Fill in the problem description, select your district (e.g. Ranchi, Palamu, Bokaro), attach GPS location or photos. The system categorizes it automatically and routes it to institutional solvers.",
      timestamp: new Date(Date.now() + 500).toISOString(),
      likes: 2,
    };
    store.chatMessages.push(autoReply);
  } else if (lower.includes("hospital") || lower.includes("doctor") || lower.includes("ambulance") || lower.includes("medicine")) {
    autoReply = {
      id: "MSG-" + crypto.randomUUID().slice(0, 8),
      channel: validChannel,
      senderName: "JanSamadhan Desk",
      senderRole: "Government Helpdesk",
      isOfficial: true,
      text: "Government hospitals, OPD slot booking, essential generic medicines, and live 108/102 ambulance dispatch are available under the 'Public Services' tab.",
      timestamp: new Date(Date.now() + 500).toISOString(),
      likes: 1,
    };
    store.chatMessages.push(autoReply);
  }

  return res.status(201).json({
    ok: true,
    message: userMsg,
    reply: autoReply,
  });
});

// POST /api/chat/like
app.post("/api/chat/like", (req, res) => {
  const { messageId } = req.body || {};
  const msg = store.chatMessages.find((m) => m.id === messageId);
  if (!msg) return res.status(404).json({ error: "Message not found." });
  msg.likes = (msg.likes || 0) + 1;
  return res.json({ ok: true, likes: msg.likes });
});

// Uploads POST
app.post("/api/uploads", upload.single("file") as any, (req, res) => {
  const file = req.file;
  if (!file) {
    return res.status(400).json({ error: "Choose a file to upload." });
  }
  return res.json({ ok: true, key: `evidence/${file.filename}`, name: file.originalname });
});

// Vite middleware or production build static serve
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (_req, res) => {
      res.sendFile(path.resolve(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[JanSamadhan] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
