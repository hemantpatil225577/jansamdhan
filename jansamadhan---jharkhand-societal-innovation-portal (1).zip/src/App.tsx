/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Portal from "./portal";

export default function App() {
  return <Portal />;
}

