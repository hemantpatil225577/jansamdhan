"use client";

import { useEffect, useRef, useState } from "react";
import {
  Activity,
  CheckCircle2,
  ChevronRight,
  ExternalLink,
  GraduationCap,
  HelpCircle,
  Info,
  Landmark,
  Loader2,
  Maximize2,
  MessageSquare,
  Minimize2,
  PhoneCall,
  Search,
  Send,
  Sparkles,
  Sprout,
  Target,
  ThumbsUp,
  X,
} from "lucide-react";
import "./chatbox.css";

export interface ChatMessage {
  id: string;
  channel: string;
  senderName: string;
  senderRole: string;
  text: string;
  challengeId?: string;
  challengePreview?: {
    id: string;
    title: string;
    status: string;
    district: string;
    progress: number;
    category: string;
  };
  isOfficial?: boolean;
  timestamp: string;
  likes?: number;
}

interface ChannelDef {
  id: string;
  name: string;
  icon: string;
  desc?: string;
}

const CHANNELS: ChannelDef[] = [
  { id: "all", name: "All Topics", icon: "all", desc: "Combined stream across all channels" },
  { id: "helpdesk", name: "Citizen Helpdesk (सहायता)", icon: "helpdesk", desc: "Citizen grievances, queries & official support" },
  { id: "tracker", name: "Challenge Tracker (ट्रैकर)", icon: "tracker", desc: "Real-time updates on active Jharkhand challenges" },
  { id: "innovators", name: "Solvers & Labs (अनुसंधान)", icon: "innovators", desc: "Universities (BIT Mesra, BAU, CUJ) & industry prototypes" },
  { id: "rural", name: "Rural & Agri (कृषि)", icon: "rural", desc: "Farmer innovations, cold-storage, solar & SHGs" },
];

const QUICK_PROMPTS = [
  "Track JH-24018 status",
  "How to submit a challenge?",
  "Emergency helplines",
  "Hospital bed availability",
  "Which universities are active?",
];

function formatTime(iso: string) {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  } catch {
    return "Just now";
  }
}

// -------------------------------------------------------------
// Floating Chatbox Component
// -------------------------------------------------------------
export function FloatingChatWidget({
  profileName,
  role,
  onOpenChallenge,
  onOpenSubmit,
}: {
  profileName?: string;
  role?: string;
  onOpenChallenge?: (id: string) => void;
  onOpenSubmit?: () => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [activeChannel, setActiveChannel] = useState("all");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [customRole, setCustomRole] = useState(role || "Citizen");
  const [customName, setCustomName] = useState(profileName || "");
  const [unreadCount, setUnreadCount] = useState(0);

  const streamEndRef = useRef<HTMLDivElement>(null);

  // Sync profile name when logged in
  useEffect(() => {
    if (profileName) setCustomName(profileName);
    if (role) setCustomRole(role);
  }, [profileName, role]);

  // Fetch messages
  const fetchMessages = async (showLoading = false) => {
    try {
      const channelParam = activeChannel !== "all" ? `&channel=${encodeURIComponent(activeChannel)}` : "";
      const searchParam = searchQuery ? `&q=${encodeURIComponent(searchQuery)}` : "";
      const res = await fetch(`/api/chat?action=list${channelParam}${searchParam}`, { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
      }
    } catch (err) {
      console.error("Chat fetch error:", err);
    }
  };

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(() => fetchMessages(), 10000);
    return () => clearInterval(interval);
  }, [activeChannel, searchQuery]);

  useEffect(() => {
    if (isOpen && !isMinimized) {
      setUnreadCount(0);
      streamEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isOpen, isMinimized]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isSending) return;

    setIsSending(true);
    setInputText("");

    try {
      const targetChannel = activeChannel === "all" ? "helpdesk" : activeChannel;
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          channel: targetChannel,
          senderName: customName.trim() || (profileName || "Concerned Citizen"),
          senderRole: customRole,
          text,
        }),
      });

      if (res.ok) {
        await fetchMessages();
        streamEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }
    } catch (e) {
      console.error("Send message error:", e);
    } finally {
      setIsSending(false);
    }
  };

  const handleLike = async (messageId: string) => {
    try {
      const res = await fetch("/api/chat/like", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messageId }),
      });
      if (res.ok) {
        const data = await res.json();
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, likes: data.likes } : m))
        );
      }
    } catch (err) {
      console.error("Like error:", err);
    }
  };

  return (
    <>
      {/* Floating Trigger Button */}
      {!isOpen && (
        <button
          className="floating-chat-btn"
          onClick={() => {
            setIsOpen(true);
            setIsMinimized(false);
          }}
          aria-label="Open JanSamadhan Chatbox"
        >
          <span className="live-dot" />
          <MessageSquare />
          <span className="label-text">Jan Samvaad Chat</span>
          <span className="badge-pill">Live</span>
        </button>
      )}

      {/* Floating Chat Window */}
      {isOpen && (
        <div className={`chatbox-floating-window ${isMinimized ? "minimized" : ""}`}>
          {/* Header */}
          <div className="chatbox-header">
            <div className="chatbox-title-group">
              <div className="chatbox-logo">ज</div>
              <div className="chatbox-title-text">
                <h3>Jan Samvaad Chat</h3>
                <span>
                  <i className="online-ping" /> Active citizen & research desk
                </span>
              </div>
            </div>

            <div className="chatbox-controls">
              <button
                className="chatbox-ctrl-btn"
                title="Search messages"
                onClick={() => setShowSearch(!showSearch)}
              >
                <Search />
              </button>
              <button
                className="chatbox-ctrl-btn"
                title={isMinimized ? "Expand" : "Minimize"}
                onClick={() => setIsMinimized(!isMinimized)}
              >
                {isMinimized ? <Maximize2 /> : <Minimize2 />}
              </button>
              <button
                className="chatbox-ctrl-btn"
                title="Close"
                onClick={() => setIsOpen(false)}
              >
                <X />
              </button>
            </div>
          </div>

          {!isMinimized && (
            <>
              {/* Channel Selector Pills */}
              <div className="chatbox-channels-bar">
                {CHANNELS.map((ch) => (
                  <button
                    key={ch.id}
                    className={`channel-chip ${activeChannel === ch.id ? "active" : ""}`}
                    onClick={() => setActiveChannel(ch.id)}
                  >
                    {ch.name}
                  </button>
                ))}
              </div>

              {/* Optional Search Bar */}
              {showSearch && (
                <div className="chat-search-wrap">
                  <Search />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search queries, keywords, or JH- IDs..."
                    autoFocus
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery("")}
                      style={{ border: 0, background: "transparent", cursor: "pointer" }}
                    >
                      <X style={{ width: 12, height: 12 }} />
                    </button>
                  )}
                </div>
              )}

              {/* Quick Prompts */}
              <div className="chat-quick-chips">
                {QUICK_PROMPTS.map((q) => (
                  <button
                    key={q}
                    className="prompt-chip"
                    onClick={() => handleSend(q)}
                  >
                    {q}
                  </button>
                ))}
              </div>

              {/* Chat Message Stream */}
              <div className="chatbox-stream">
                {messages.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "30px 10px", color: "var(--muted)", fontSize: 12 }}>
                    <MessageSquare style={{ width: 32, height: 32, margin: "0 auto 8px", opacity: 0.4 }} />
                    <b>No messages found</b>
                    <p style={{ margin: "4px 0 0", fontSize: 11 }}>
                      Ask a query below or select a quick topic above.
                    </p>
                  </div>
                ) : (
                  messages.map((msg) => {
                    const isOfficial = msg.isOfficial || msg.senderRole.includes("Helpdesk") || msg.senderRole.includes("Government");
                    const roleClass = isOfficial
                      ? "official"
                      : msg.senderRole.toLowerCase().includes("university")
                      ? "university"
                      : msg.senderRole.toLowerCase().includes("industry")
                      ? "industry"
                      : "citizen";

                    return (
                      <div
                        key={msg.id}
                        className={`chat-msg-row ${isOfficial ? "official" : "incoming"}`}
                      >
                        <div className="chat-msg-meta">
                          <span className="chat-sender-name">{msg.senderName}</span>
                          <span className={`role-tag ${roleClass}`}>{msg.senderRole}</span>
                          <span>• {formatTime(msg.timestamp)}</span>
                        </div>

                        <div className="chat-msg-bubble">
                          {isOfficial && (
                            <div className="official-crest">
                              <Landmark />
                              <span>Verified JanSamadhan Official Response</span>
                            </div>
                          )}

                          <div style={{ whiteSpace: "pre-wrap" }}>{msg.text}</div>

                          {/* Embedded Challenge Preview Card */}
                          {msg.challengePreview && (
                            <div className="chat-challenge-card">
                              <div className="chat-challenge-head">
                                <b>{msg.challengePreview.id}</b>
                                <span className={`priority ${msg.challengePreview.status.toLowerCase().replace(/\s+/g, "-")}`}>
                                  {msg.challengePreview.status}
                                </span>
                              </div>
                              <h4 className="chat-challenge-title">{msg.challengePreview.title}</h4>
                              <div className="chat-challenge-bar">
                                <i style={{ width: `${msg.challengePreview.progress}%` }} />
                              </div>
                              <div className="chat-challenge-foot">
                                <span>{msg.challengePreview.district} · {msg.challengePreview.progress}% progress</span>
                                {onOpenChallenge && (
                                  <button
                                    onClick={() => onOpenChallenge(msg.challengePreview!.id)}
                                    title="View challenge"
                                  >
                                    View Challenge →
                                  </button>
                                )}
                              </div>
                            </div>
                          )}

                          <div className="chat-bubble-foot">
                            <button
                              className="like-btn"
                              onClick={() => handleLike(msg.id)}
                              title="Upvote / Support"
                            >
                              <ThumbsUp /> {msg.likes || 0}
                            </button>
                            <span style={{ fontSize: 9 }}>{msg.channel.toUpperCase()}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={streamEndRef} />
              </div>

              {/* Composer */}
              <div className="chatbox-composer">
                <div className="composer-identity-bar">
                  <div className="identity-badge">
                    <span>Posting as:</span>
                    <input
                      type="text"
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      placeholder="Your Name"
                      style={{
                        border: "1px solid #d4e0dd",
                        borderRadius: 6,
                        padding: "2px 6px",
                        fontSize: 10,
                        width: 90,
                      }}
                    />
                    <select
                      value={customRole}
                      onChange={(e) => setCustomRole(e.target.value)}
                    >
                      <option>Citizen</option>
                      <option>University</option>
                      <option>Industry</option>
                      <option>Government</option>
                    </select>
                  </div>

                  {onOpenSubmit && (
                    <button
                      onClick={onOpenSubmit}
                      style={{
                        border: 0,
                        background: "transparent",
                        color: "#176b5b",
                        fontSize: 10,
                        fontWeight: 750,
                        cursor: "pointer",
                      }}
                    >
                      + File Issue
                    </button>
                  )}
                </div>

                <div className="composer-input-row">
                  <textarea
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSend();
                      }
                    }}
                    placeholder="Type your query or mention challenge (e.g. JH-24018)..."
                    rows={1}
                  />
                  <button
                    className="send-btn"
                    disabled={!inputText.trim() || isSending}
                    onClick={() => handleSend()}
                    title="Send message"
                  >
                    {isSending ? <Loader2 className="spin" style={{ width: 14, height: 14 }} /> : <Send />}
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}

// -------------------------------------------------------------
// Full Page Version (Jan Samvaad Page)
// -------------------------------------------------------------
export function ChatPage({
  profileName,
  role,
  onOpenChallenge,
  onOpenSubmit,
}: {
  profileName?: string;
  role?: string;
  onOpenChallenge?: (id: string) => void;
  onOpenSubmit?: () => void;
}) {
  const [activeChannel, setActiveChannel] = useState("all");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [customRole, setCustomRole] = useState(role || "Citizen");
  const [customName, setCustomName] = useState(profileName || "");

  const streamEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (profileName) setCustomName(profileName);
    if (role) setCustomRole(role);
  }, [profileName, role]);

  const fetchMessages = async () => {
    try {
      const channelParam = activeChannel !== "all" ? `&channel=${encodeURIComponent(activeChannel)}` : "";
      const searchParam = searchQuery ? `&q=${encodeURIComponent(searchQuery)}` : "";
      const res = await fetch(`/api/chat?action=list${channelParam}${searchParam}`, { cache: "no-store" });
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
      }
    } catch (err) {
      console.error("Chat page fetch error:", err);
    }
  };

  useEffect(() => {
    fetchMessages();
    const interval = setInterval(() => fetchMessages(), 10000);
    return () => clearInterval(interval);
  }, [activeChannel, searchQuery]);

  useEffect(() => {
    streamEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isSending) return;

    setIsSending(true);
    setInputText("");

    try {
      const targetChannel = activeChannel === "all" ? "helpdesk" : activeChannel;
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          channel: targetChannel,
          senderName: customName.trim() || (profileName || "Concerned Citizen"),
          senderRole: customRole,
          text,
        }),
      });

      if (res.ok) {
        await fetchMessages();
        streamEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }
    } catch (e) {
      console.error("Send message error:", e);
    } finally {
      setIsSending(false);
    }
  };

  const handleLike = async (messageId: string) => {
    try {
      const res = await fetch("/api/chat/like", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messageId }),
      });
      if (res.ok) {
        const data = await res.json();
        setMessages((prev) =>
          prev.map((m) => (m.id === messageId ? { ...m, likes: data.likes } : m))
        );
      }
    } catch (err) {
      console.error("Like error:", err);
    }
  };

  const getChannelIcon = (iconName: string) => {
    switch (iconName) {
      case "helpdesk":
        return <Landmark />;
      case "tracker":
        return <Target />;
      case "innovators":
        return <GraduationCap />;
      case "rural":
        return <Sprout />;
      default:
        return <MessageSquare />;
    }
  };

  return (
    <div className="page" style={{ paddingBottom: 30 }}>
      {/* Page Header */}
      <div className="page-head">
        <div>
          <span>Jharkhand Societal Innovation · Community & Grievance Desk</span>
          <h1>Jan Samvaad Chatbox</h1>
          <p>
            Connect directly with citizens, researchers, student innovators, and nodal officers across all 24 districts of Jharkhand.
          </p>
        </div>
        {onOpenSubmit && (
          <button className="primary" onClick={onOpenSubmit}>
            + Submit Challenge
          </button>
        )}
      </div>

      {/* 3-Column Layout */}
      <div className="chat-page-container">
        {/* Left Column: Channels */}
        <aside className="chat-sidebar-panel">
          <div className="chat-sidebar-head">
            <h2>
              <MessageSquare style={{ width: 18, height: 18, color: "#176b5b" }} />
              Chat Channels
            </h2>
            <p>Select a topic to focus discussion</p>
          </div>

          <div className="chat-channel-list">
            {CHANNELS.map((ch) => (
              <button
                key={ch.id}
                className={`chat-channel-btn ${activeChannel === ch.id ? "active" : ""}`}
                onClick={() => setActiveChannel(ch.id)}
              >
                <div className="ch-icon">{getChannelIcon(ch.icon)}</div>
                <div>
                  <b>{ch.name}</b>
                  <small>{ch.desc}</small>
                </div>
              </button>
            ))}
          </div>

          <div style={{ padding: 14, background: "#f8faf9", borderTop: "1px solid var(--line)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7, fontSize: 11, color: "#176b5b", fontWeight: 750 }}>
              <span className="live-dot" />
              <span>48 Citizens & Researchers Active Today</span>
            </div>
          </div>
        </aside>

        {/* Center Column: Chat Stream */}
        <main className="chat-main-panel">
          {/* Channel Header inside chat */}
          <div style={{ padding: "14px 18px", borderBottom: "1px solid var(--line)", background: "#ffffff", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <b style={{ fontSize: 15, color: "#10243e" }}>
                {CHANNELS.find((c) => c.id === activeChannel)?.name || "Live Chat"}
              </b>
              <p style={{ margin: "2px 0 0", fontSize: 11, color: "var(--muted)" }}>
                {CHANNELS.find((c) => c.id === activeChannel)?.desc || "Real-time community conversation"}
              </p>
            </div>

            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, background: "#f4f8f7", padding: "6px 10px", borderRadius: 8, border: "1px solid #d8e4e0" }}>
                <Search style={{ width: 14, height: 14, color: "#6e847e" }} />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter messages..."
                  style={{ border: 0, outline: 0, background: "transparent", fontSize: 11, width: 140 }}
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery("")} style={{ border: 0, background: "transparent", cursor: "pointer" }}>
                    <X style={{ width: 12, height: 12 }} />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Quick Prompts */}
          <div className="chat-quick-chips">
            {QUICK_PROMPTS.map((q) => (
              <button key={q} className="prompt-chip" onClick={() => handleSend(q)}>
                {q}
              </button>
            ))}
          </div>

          {/* Stream */}
          <div className="chatbox-stream" style={{ flex: 1 }}>
            {messages.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 10px", color: "var(--muted)" }}>
                <MessageSquare style={{ width: 42, height: 42, margin: "0 auto 12px", opacity: 0.3 }} />
                <b style={{ fontSize: 14 }}>No messages in this channel yet</b>
                <p style={{ fontSize: 12, marginTop: 4 }}>Be the first to post a query or update!</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isOfficial = msg.isOfficial || msg.senderRole.includes("Helpdesk") || msg.senderRole.includes("Government");
                const roleClass = isOfficial
                  ? "official"
                  : msg.senderRole.toLowerCase().includes("university")
                  ? "university"
                  : msg.senderRole.toLowerCase().includes("industry")
                  ? "industry"
                  : "citizen";

                return (
                  <div
                    key={msg.id}
                    className={`chat-msg-row ${isOfficial ? "official" : "incoming"}`}
                    style={{ maxWidth: "85%" }}
                  >
                    <div className="chat-msg-meta">
                      <span className="chat-sender-name">{msg.senderName}</span>
                      <span className={`role-tag ${roleClass}`}>{msg.senderRole}</span>
                      <span>• {formatTime(msg.timestamp)}</span>
                    </div>

                    <div className="chat-msg-bubble">
                      {isOfficial && (
                        <div className="official-crest">
                          <Landmark />
                          <span>Verified JanSamadhan Official Response</span>
                        </div>
                      )}

                      <div style={{ whiteSpace: "pre-wrap" }}>{msg.text}</div>

                      {msg.challengePreview && (
                        <div className="chat-challenge-card">
                          <div className="chat-challenge-head">
                            <b>{msg.challengePreview.id}</b>
                            <span className={`priority ${msg.challengePreview.status.toLowerCase().replace(/\s+/g, "-")}`}>
                              {msg.challengePreview.status}
                            </span>
                          </div>
                          <h4 className="chat-challenge-title">{msg.challengePreview.title}</h4>
                          <div className="chat-challenge-bar">
                            <i style={{ width: `${msg.challengePreview.progress}%` }} />
                          </div>
                          <div className="chat-challenge-foot">
                            <span>{msg.challengePreview.district} · {msg.challengePreview.progress}% progress</span>
                            {onOpenChallenge && (
                              <button
                                onClick={() => onOpenChallenge(msg.challengePreview!.id)}
                                title="View challenge"
                              >
                                View Challenge →
                              </button>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="chat-bubble-foot">
                        <button
                          className="like-btn"
                          onClick={() => handleLike(msg.id)}
                          title="Upvote / Support"
                        >
                          <ThumbsUp /> {msg.likes || 0}
                        </button>
                        <span style={{ fontSize: 9 }}>{msg.channel.toUpperCase()}</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={streamEndRef} />
          </div>

          {/* Composer */}
          <div className="chatbox-composer">
            <div className="composer-identity-bar">
              <div className="identity-badge">
                <span>Posting as:</span>
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  placeholder="Your Name"
                  style={{
                    border: "1px solid #d4e0dd",
                    borderRadius: 6,
                    padding: "3px 8px",
                    fontSize: 11,
                    width: 140,
                  }}
                />
                <select
                  value={customRole}
                  onChange={(e) => setCustomRole(e.target.value)}
                >
                  <option>Citizen</option>
                  <option>University</option>
                  <option>Industry</option>
                  <option>Government</option>
                </select>
              </div>

              <span style={{ fontSize: 10, color: "var(--muted)" }}>
                Press <b>Enter</b> to send, <b>Shift+Enter</b> for new line
              </span>
            </div>

            <div className="composer-input-row">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder="Share an innovation idea, ask for problem status, or post a village query..."
                rows={2}
              />
              <button
                className="send-btn"
                disabled={!inputText.trim() || isSending}
                onClick={() => handleSend()}
                title="Send message"
              >
                {isSending ? <Loader2 className="spin" style={{ width: 16, height: 16 }} /> : <Send />}
              </button>
            </div>
          </div>
        </main>

        {/* Right Column: Helpline Directory & FAQ */}
        <aside className="chat-info-panel">
          <div className="chat-info-head">
            <span>Verified Helplines & Guides</span>
          </div>

          <div className="chat-info-body">
            <div className="helpline-card">
              <h4>
                <PhoneCall style={{ width: 14, height: 14 }} /> Emergency & Nodal Numbers
              </h4>
              <div className="helpline-list">
                <div className="helpline-item">
                  <span>CM JanSamadhan Helpline</span>
                  <b>181</b>
                </div>
                <div className="helpline-item">
                  <span>Emergency Response (Police/Fire)</span>
                  <b>112</b>
                </div>
                <div className="helpline-item">
                  <span>108 Medical Ambulance</span>
                  <b>108</b>
                </div>
                <div className="helpline-item">
                  <span>Kisan Call Centre</span>
                  <b>1800-180-1551</b>
                </div>
                <div className="helpline-item">
                  <span>Drinking Water & Sanitation</span>
                  <b>1800-345-6512</b>
                </div>
              </div>
            </div>

            <div className="helpline-card">
              <h4>
                <HelpCircle style={{ width: 14, height: 14 }} /> Quick Tips
              </h4>
              <p style={{ margin: 0, fontSize: 11, color: "var(--muted)", lineHeight: 1.5 }}>
                • Type any <b>Challenge ID</b> (e.g. <code>JH-24018</code>) to inspect live progress and assigned university.
                <br />
                • Inquiries regarding <b>public services</b> will automatically guide you to nearby hospitals and essential medicines.
                <br />
                • University labs can propose solutions via the <b>Solver Hub</b>.
              </p>
            </div>

            <div className="side-card" style={{ margin: 0, background: "#f0f7f5", border: "1px solid #c8e4db" }}>
              <CheckCircle2 style={{ width: 18, color: "#176b5b" }} />
              <b style={{ color: "#134237" }}>Transparent Civic Redressal</b>
              <p style={{ color: "#386156" }}>
                Every message posted in this hub is archived for government evaluation and university matching.
              </p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
