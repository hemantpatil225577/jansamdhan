# Email OTP authentication

JanSamadhan now uses real server-side email OTP. This replaces the earlier demo, where the browser generated the code and showed it in an `alert()`. The email delivery works the same way as in FOC PROJECT (Gmail SMTP, STARTTLS on port 587, app password). It has been rewritten in TypeScript for Cloudflare Workers using `cloudflare:sockets`, because Python `smtplib`/Flask cannot run there.

## Flow
Everything goes through the existing `POST /api/portal` endpoint and the existing `users` / `sessions` tables and `js_session` cookie.

| action | body | result |
|---|---|---|
| `requestOtp` | `{mode:"signup", email, name, phone, role}` or `{mode:"login", email, role?}` | Emails a 6-digit code. Returns `{challengeId, maskedEmail, expiresIn, resendIn, resendsLeft}` and **never the code** |
| `resendOtp` | `{challengeId, email}` | Sends a new code (the old one stops working). Subject to cooldown and a resend limit |
| `verifyOtp` | `{challengeId, email, otp}` | Uses up the code, creates the user (signup) or updates the role (login), and sets the `js_session` cookie (HttpOnly, 7 days) |
| `logout` | `{}` | Deletes the session |

`GET /api/portal?action=session` returns the signed-in user (it is now joined with `users`).

The roles Citizen, University, Industry and Government are checked against an allow-list on the server.

## Security
- The code is generated with `crypto.getRandomValues` and rejection sampling, so every 6-digit value is equally likely.
- Only `HMAC-SHA256(OTP_SECRET, challengeId:email:otp)` is stored, in `otp_challenges`. The plain code is never stored, logged or returned by the API.
- Codes expire after 5 minutes (`OTP_EXPIRY_SECONDS`).
- Each code works once: it is consumed by an atomic conditional `UPDATE`. Requesting a new code invalidates earlier ones.
- After 5 wrong attempts (`OTP_MAX_ATTEMPTS`) the code is locked. The attempt is counted atomically before the comparison, and the comparison is constant-time.
- Resending has a 60 s cooldown (`OTP_RESEND_COOLDOWN_SECONDS`) and a limit of 3 (`OTP_MAX_RESENDS`). There are also hourly caps per email and per IP.
- All credentials come from environment variables or Worker secrets only. If they are missing, the endpoint returns HTTP 503.

## Setup
1. `openssl rand -hex 32` → `OTP_SECRET`
2. Gmail: turn on 2-Step Verification, then create an App Password → `SMTP_USER` / `SMTP_PASSWORD`
   (the FOC names `SENDER_EMAIL` / `SENDER_APP_PASSWORD` also work)
3. Local: copy `.env.example` to `.dev.vars`. Production: `npx wrangler secret put SMTP_PASSWORD` (and the others)
4. Apply `drizzle/0006_email_otp.sql`

Port 25 is blocked for outbound Worker sockets. Use 587 (starttls) or 465 (tls).
